# Category Management Portfolio — Independent Business Case Studies
Prepared 11 November 2026

## Project 1 — TinyNest
**Baby Essentials Category Intelligence & Smart Replenishment**
An independently conceived category strategy case study focused on product profitability, essential-SKU availability, store-level stock risk, demand signals and replenishment planning.

## Project 2 — FreshBasket
**Grocery Category Performance & Intelligent Assortment Strategy**
An independently conceived case study focused on grocery profitability, basket attachment, private-label mix, freshness loss and product assortment decisions.

## Data transparency
Both projects use synthetic, reproducible portfolio datasets. They do not represent any named company's internal sales, customer, cost, inventory or supplier data. The fictional retailer concepts and analysis are original portfolio exercises based on common retail business problems.

## Suggested GitHub repositories
1. `tinynest-baby-essentials-category-intelligence`
2. `freshbasket-grocery-assortment-intelligence`

## Resume wording
**TinyNest | Baby Essentials Category Intelligence & Smart Replenishment — Independent Case Study**
Built a synthetic six-month quick-commerce dataset and analysed SKU profitability, store-level availability, stockout exposure and replenishment priorities using SQL, Python and Power BI.

**FreshBasket | Grocery Category Performance & Intelligent Assortment Strategy — Independent Case Study**
Developed a quality-led grocery category case study analysing category contribution, basket attachment, private-label mix, freshness waste and SKU assortment decisions using SQL, Python and Power BI.

Do not claim employment, internship, affiliation, or measurable business impact at any real company.
