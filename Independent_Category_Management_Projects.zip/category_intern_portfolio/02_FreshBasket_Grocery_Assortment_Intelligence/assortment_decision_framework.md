# Assortment Decision Framework

Use a transparent scorecard, not an opaque "AI recommendation".

## Dimensions
- **Commercial:** net sales, gross profit, gross margin, unit velocity.
- **Basket role:** basket penetration and attachment potential.
- **Quality/brand promise:** verified quality documentation, supplier reliability, ingredient disclosure and customer feedback (real data required).
- **Operations:** shelf life, waste, rejection, stockouts, lead time and MOQ.
- **Strategic role:** traffic driver, staple, seasonal, discovery, private-label differentiator.

## Initial decision rules (tune with business owners)
- **EXPAND:** strong gross profit/velocity, positive basket role, acceptable service and quality evidence.
- **PROTECT:** high-repeat staple or basket anchor; prioritise availability even if margin is moderate.
- **TEST:** promising attachment or differentiated product but insufficient sample size; run a time-boxed controlled test.
- **REVIEW:** weak sales plus weak basket role, high waste or repeated supplier issues; investigate before delisting.
- **SEASONAL:** demand is time-bound; plan buys and markdowns around seasonality.

## Suggested scorecard
Create a 1–5 rating for Commercial, Basket Role, Quality Evidence and Operational Fit. Weight the dimensions only after stakeholder agreement. A high commercial score must never override a failed mandatory quality/compliance gate.

## Interview talking point
“For a quality-first retailer, assortment is not about listing the maximum number of SKUs. I would protect trusted staples, expand differentiated winners, test adjacencies, and remove complexity only after checking customer and quality impact.”
