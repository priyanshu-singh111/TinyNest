# Power BI Dashboard Specification

## Page 1 — Grocery Category Scorecard
**Cards:** Net Sales, Gross Profit, Gross Margin %, Baskets, Units Sold, Private Label Sales Mix.  
**Charts:** Category sales/profit; monthly category trend; category x city matrix; margin vs sales scatter.  
**Slicers:** Month, city, category, subcategory, brand type.

## Page 2 — Basket & Assortment
**Charts:** Top products by basket penetration; category co-occurrence matrix; private label vs external brand; SKU sales/profit quadrant.  
**Table:** SKU, subcategory, brand type, net sales, gross profit, margin %, units, basket count, decision tag.

## Page 3 — Freshness & Waste
**Cards:** Waste Units, Waste Rate, Quality Reject Units, Zero Stock Days.  
**Charts:** Waste by fresh subcategory; daily waste trend; clubhouse x SKU risk matrix; stock vs sales.  
**Slicers:** Clubhouse, fresh/non-fresh, category.

## Suggested DAX
```DAX
Net Sales = SUMX(order_lines, order_lines[quantity]*order_lines[unit_selling_price_inr]*(1-order_lines[is_returned]))
Gross Profit = SUMX(order_lines, order_lines[quantity]*(order_lines[unit_selling_price_inr]-order_lines[unit_cost_inr])*(1-order_lines[is_returned]))
Gross Margin % = DIVIDE([Gross Profit],[Net Sales])
Waste Units = SUM(inventory_daily[waste_units])
Waste Rate = DIVIDE([Waste Units], [Waste Units] + SUM(inventory_daily[units_sold]))
Basket Count = DISTINCTCOUNT(order_lines[basket_id])
```
