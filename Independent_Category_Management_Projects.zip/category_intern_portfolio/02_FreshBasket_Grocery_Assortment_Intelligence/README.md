# FreshBasket | Grocery Category Performance & Intelligent Assortment Strategy
**Portfolio case study · Data window: 1 May–31 October 2026 · Prepared: 11 November 2026**

## Business question
How can a quality-first grocery commerce platform curate the right assortment, grow profitable baskets and protect freshness/quality while controlling waste and inventory complexity?

This case study reflects a quality-first grocery retailer market positioning around quality-led, curated groceries, private-label-led selection and product categories such as fresh produce, dairy, bakery, staples, packaged foods, snacks and nutrition. It is an independent portfolio project, not commissioned by or affiliated with FreshBasket.

## Important data note
All order, customer, clubhouse, cost, stock, quality-score and waste records are **synthetic demonstration data**, not any retailer's internal data. Public information informs the business context and category taxonomy only. Simulated quality fields are operational proxies for this exercise; they do not establish food safety or regulatory compliance.

## Deliverables
- `data/sku_master.csv`: 84 illustrative SKUs across seven grocery categories.
- `data/order_lines.csv`: 6 months of synthetic order-line and basket data (8,500 rows).
- `data/inventory_daily.csv`: October daily SKU-clubhouse stock, waste and rejection snapshots.
- `sql/analysis_queries.sql`: category contribution, basket attachment, private-label, quality and waste queries.
- `src/analyze.py`: reproducible analysis; outputs category, SKU, basket and assortment scorecards.
- `dashboard_spec.md`: Power BI dashboard plan and measures.
- `assortment_decision_framework.md`: transparent keep/test/expand/review rules.

## Run locally
```bash
pip install -r requirements.txt
python src/analyze.py
```

## KPIs
- Net sales = quantity × selling price, excluding returned units.
- Gross profit = net sales − unit cost, excluding returned units.
- Gross margin % = gross profit / net sales.
- Waste rate = waste units / (units sold + waste units), a simplified proxy.
- Quality-screen pass rate is a simulated product attribute; it is not a certification.
- Basket attachment = baskets containing SKU / total baskets in selected segment.

## Analytical questions
1. Which categories create gross profit and repeat basket value?
2. Which products are basket anchors and which are attachment opportunities?
3. Does private label show a different margin/velocity profile from external brands?
4. Which fresh SKUs have the highest waste or rejection exposure?
5. Which products should be expanded, tested, reviewed or rationalised?

## Decision guardrails
- Never infer health benefits, safety or regulatory compliance from the synthetic ingredient-screen flag.
- Freshness and quality must be governed by auditable supplier specifications, sampling protocols and actual lab/quality records.
- Do not delist an SKU solely because of low sales; assess strategic role, customer need, substitution and availability.
- This synthetic sample is designed for portfolio demonstration, not forecasting or operational decisions.

## Suggested GitHub description
`A quality-first grocery category management case study: category profitability, basket attachment, private-label mix, freshness loss and SKU assortment decisions using SQL, Python and Power BI.`
