from pathlib import Path
import pandas as pd
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
OUT = ROOT / "outputs"
OUT.mkdir(exist_ok=True)

sku = pd.read_csv(DATA / "sku_master.csv")
orders = pd.read_csv(DATA / "order_lines.csv", parse_dates=["order_date"])
inv = pd.read_csv(DATA / "inventory_daily.csv", parse_dates=["snapshot_date"])

orders["net_units"] = orders["quantity"]*(1-orders["is_returned"])
orders["net_sales_inr"] = orders["net_units"]*orders["unit_selling_price_inr"]
orders["gross_profit_inr"] = orders["net_units"]*(orders["unit_selling_price_inr"]-orders["unit_cost_inr"])

joined = orders.merge(sku, on="sku_id")
category = joined.groupby(["category","subcategory"],as_index=False).agg(
    net_sales_inr=("net_sales_inr","sum"),gross_profit_inr=("gross_profit_inr","sum"),
    net_units=("net_units","sum"),baskets=("basket_id","nunique")
)
category["gross_margin_pct"] = category["gross_profit_inr"]/category["net_sales_inr"].replace(0,np.nan)
category.to_csv(OUT/"category_scorecard.csv",index=False)

sku_perf = joined.groupby("sku_id",as_index=False).agg(
    net_sales_inr=("net_sales_inr","sum"),gross_profit_inr=("gross_profit_inr","sum"),
    net_units=("net_units","sum"),basket_count=("basket_id","nunique")
).merge(sku,on="sku_id")
sku_perf["gross_margin_pct"] = sku_perf["gross_profit_inr"]/sku_perf["net_sales_inr"].replace(0,np.nan)
sku_perf["decision_tag"] = np.select(
    [sku_perf["net_units"]>=sku_perf["net_units"].quantile(.75),
     sku_perf["gross_profit_inr"]>=sku_perf["gross_profit_inr"].quantile(.75),
     sku_perf["net_units"]<=sku_perf["net_units"].quantile(.25)],
    ["PROTECT / TEST EXPANSION","EXPAND / TEST","REVIEW"],
    default="MONITOR"
)
sku_perf.sort_values("gross_profit_inr",ascending=False).to_csv(OUT/"sku_assortment_scorecard.csv",index=False)

basket = orders.groupby("basket_id",as_index=False).agg(distinct_skus=("sku_id","nunique"),units=("quantity","sum"))
basket.to_csv(OUT/"basket_metrics.csv",index=False)

waste = inv.merge(sku[["sku_id","category","subcategory","is_fresh"]],on="sku_id")
waste_summary = waste.groupby(["category","subcategory"],as_index=False).agg(
    units_sold=("units_sold","sum"),waste_units=("waste_units","sum"),
    quality_reject_units=("quality_reject_units","sum")
)
waste_summary["waste_rate"] = waste_summary["waste_units"]/(waste_summary["units_sold"]+waste_summary["waste_units"]).replace(0,np.nan)
waste_summary.to_csv(OUT/"freshness_waste_scorecard.csv",index=False)

mix = joined.groupby("brand_type",as_index=False).agg(
    net_sales_inr=("net_sales_inr","sum"),gross_profit_inr=("gross_profit_inr","sum"),
    baskets=("basket_id","nunique")
)
mix.to_csv(OUT/"private_label_vs_external.csv",index=False)
print("Analysis complete. Outputs saved in:", OUT)
