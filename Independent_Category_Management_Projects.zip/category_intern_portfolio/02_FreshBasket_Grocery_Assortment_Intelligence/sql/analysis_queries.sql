-- FreshBasket Grocery Category Performance & Assortment Strategy
-- Load CSVs into tables named sku_master, order_lines, inventory_daily.

-- 1. Category performance and margin
SELECT s.category, s.subcategory,
       SUM(o.quantity * o.unit_selling_price_inr * (1-o.is_returned)) AS net_sales_inr,
       SUM(o.quantity * (o.unit_selling_price_inr-o.unit_cost_inr) * (1-o.is_returned)) AS gross_profit_inr,
       SUM(o.quantity * (1-o.is_returned)) AS net_units,
       COUNT(DISTINCT o.basket_id) AS baskets
FROM order_lines o JOIN sku_master s ON o.sku_id=s.sku_id
GROUP BY s.category,s.subcategory
ORDER BY gross_profit_inr DESC;

-- 2. Private label vs external brand
SELECT s.brand_type,
       SUM(o.quantity*o.unit_selling_price_inr*(1-o.is_returned)) AS net_sales_inr,
       SUM(o.quantity*(o.unit_selling_price_inr-o.unit_cost_inr)*(1-o.is_returned)) AS gross_profit_inr,
       COUNT(DISTINCT o.basket_id) AS baskets
FROM order_lines o JOIN sku_master s ON o.sku_id=s.sku_id
GROUP BY s.brand_type;

-- 3. Basket attachment: products frequently appearing in multi-item baskets
WITH basket_sku AS (
  SELECT basket_id, sku_id, SUM(quantity) AS units
  FROM order_lines GROUP BY basket_id, sku_id
),
basket_size AS (
  SELECT basket_id, COUNT(DISTINCT sku_id) AS distinct_skus
  FROM basket_sku GROUP BY basket_id
)
SELECT s.category,s.subcategory,
       COUNT(DISTINCT b.basket_id) AS baskets_with_category,
       AVG(bs.distinct_skus * 1.0) AS avg_distinct_skus_in_basket
FROM basket_sku b
JOIN basket_size bs ON b.basket_id=bs.basket_id
JOIN sku_master s ON b.sku_id=s.sku_id
GROUP BY s.category,s.subcategory
ORDER BY baskets_with_category DESC;

-- 4. Fresh category waste and rejection
SELECT s.category,s.subcategory,
       SUM(i.units_sold) AS units_sold,
       SUM(i.waste_units) AS waste_units,
       SUM(i.quality_reject_units) AS rejected_units,
       1.0*SUM(i.waste_units)/NULLIF(SUM(i.units_sold)+SUM(i.waste_units),0) AS waste_rate
FROM inventory_daily i JOIN sku_master s ON i.sku_id=s.sku_id
GROUP BY s.category,s.subcategory
ORDER BY waste_rate DESC;

-- 5. Assortment review list: commercial performance + quality/operational flags
SELECT s.sku_id,s.product_name,s.category,s.brand_type,s.shelf_life_days,
       SUM(o.quantity*(1-o.is_returned)) AS net_units,
       SUM(o.quantity*o.unit_selling_price_inr*(1-o.is_returned)) AS net_sales_inr,
       SUM(o.quantity*(o.unit_selling_price_inr-o.unit_cost_inr)*(1-o.is_returned)) AS gross_profit_inr,
       s.quality_score,s.ingredient_screen_pass
FROM sku_master s LEFT JOIN order_lines o ON s.sku_id=o.sku_id
GROUP BY s.sku_id,s.product_name,s.category,s.brand_type,s.shelf_life_days,s.quality_score,s.ingredient_screen_pass
ORDER BY gross_profit_inr DESC;
