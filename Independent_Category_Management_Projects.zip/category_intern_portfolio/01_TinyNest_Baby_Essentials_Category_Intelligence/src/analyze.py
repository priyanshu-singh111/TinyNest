from pathlib import Path
import pandas as pd
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
OUT = ROOT / "outputs"
OUT.mkdir(exist_ok=True)

sku = pd.read_csv(DATA / "sku_master.csv")
orders = pd.read_csv(DATA / "order_lines.csv", parse_dates=["order_date"])
inv = pd.read_csv(DATA / "inventory_daily.csv", parse_dates=["snapshot_date"])

orders["net_units"] = orders["quantity"] * (1 - orders["is_returned"])
orders["net_sales_inr"] = orders["net_units"] * orders["unit_selling_price_inr"]
orders["gross_profit_inr"] = orders["net_units"] * (orders["unit_selling_price_inr"] - orders["unit_cost_inr"])
orders["discount_pct"] = np.where(
    orders["unit_selling_price_inr"] + orders["discount_per_unit_inr"] > 0,
    orders["discount_per_unit_inr"] / (orders["unit_selling_price_inr"] + orders["discount_per_unit_inr"]), 0
)

cat = orders.merge(sku[["sku_id","category","subcategory","brand"]], on="sku_id")
category = cat.groupby(["category","subcategory"], as_index=False).agg(
    net_sales_inr=("net_sales_inr","sum"), gross_profit_inr=("gross_profit_inr","sum"),
    net_units=("net_units","sum"), orders=("order_id","nunique")
)
category["gross_margin_pct"] = category["gross_profit_inr"] / category["net_sales_inr"].replace(0,np.nan)
category.to_csv(OUT/"category_performance.csv",index=False)

sku_perf = cat.groupby("sku_id",as_index=False).agg(
    net_sales_inr=("net_sales_inr","sum"), gross_profit_inr=("gross_profit_inr","sum"),
    net_units=("net_units","sum"), avg_discount_pct=("discount_pct","mean")
).merge(sku,on="sku_id")
sku_perf["gross_margin_pct"] = sku_perf["gross_profit_inr"] / sku_perf["net_sales_inr"].replace(0,np.nan)
sku_perf.sort_values("net_sales_inr",ascending=False).to_csv(OUT/"sku_performance.csv",index=False)

latest = inv.sort_values("snapshot_date").groupby(["dark_store_id","sku_id"]).tail(1).copy()
demand = inv.sort_values("snapshot_date").groupby(["dark_store_id","sku_id"]).tail(7).groupby(["dark_store_id","sku_id"],as_index=False).agg(avg_daily_units=("units_sold","mean"))
reorder = latest.merge(demand,on=["dark_store_id","sku_id"]).merge(sku[["sku_id","supplier_lead_time_days"]],on="sku_id")
reorder["target_stock"] = np.ceil(reorder["avg_daily_units"] * reorder["supplier_lead_time_days"] * 1.25)
reorder["suggested_reorder_units"] = (reorder["target_stock"] - reorder["closing_stock_units"]).clip(lower=0).astype(int)
reorder.sort_values("suggested_reorder_units",ascending=False).to_csv(OUT/"suggested_replenishment.csv",index=False)

store_risk = inv.groupby(["dark_store_id","sku_id"],as_index=False).agg(
    snapshot_days=("snapshot_date","nunique"),
    zero_stock_days=("closing_stock_units",lambda x:(x==0).sum()),
    near_expiry_units=("near_expiry_units","sum"),
    avg_closing_stock=("closing_stock_units","mean")
)
store_risk.to_csv(OUT/"store_sku_risk.csv",index=False)
print("Analysis complete. Outputs saved in:", OUT)
