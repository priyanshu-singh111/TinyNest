# Category Manager Decision Memo (Hypotheses to test)

1. **Protect availability for repeat-purchase essentials.** Segment diapers, wipes and other frequent-use SKUs by velocity and stockout exposure; set differentiated service levels rather than one blanket inventory rule.
2. **Separate traffic drivers from profit drivers.** A high-sales SKU is not automatically a high-contribution SKU. Review gross profit and discount depth together before expanding promotions.
3. **Use store-level assortment.** Keep core essentials broadly available, while testing slower-moving or larger-pack SKUs in stores with demonstrated demand.
4. **Control expiry and excess stock.** Monitor near-expiry exposure daily for relevant items; use compliant FEFO processes and supplier return/markdown rules where applicable.
5. **Improve replenishment inputs.** Replace the demo reorder formula with demand variability, supplier reliability, MOQ, case pack, fill rate and target service level.

**Interview talking point:** “I would not maximise SKU count or sales alone. For baby care, I would balance trusted selection, repeat availability, margin, and inventory risk at each store.”
