# TinyNest | Baby Essentials Category Intelligence & Smart Replenishment
**Portfolio case study · Data window: 1 May–31 October 2026 · Prepared: 11 November 2026**

## Business question
How should a vertical quick-commerce retailer improve baby-care category availability and contribution while protecting trust, avoiding avoidable markdowns, and keeping the right products close to parents?

This case study is designed around a curated baby-and-kids quick-commerce assortment (diapers & essentials, formula, skin/hair/body care, feeding bottles, blankets/swaddles and grooming essentials). It is an independent portfolio project, not commissioned by or affiliated with TinyNest.

## Important data note
All transaction, customer, store, inventory and cost records in `data/` are **synthetic, reproducible demonstration data**. They are not any retailer's internal data and must not be represented as actual company performance. The assortment taxonomy is informed by public category information; product names and commercial metrics are simulated.

## Project deliverables
- `data/sku_master.csv`: 80 illustrative SKUs, category, age stage, price, cost and supplier lead time.
- `data/order_lines.csv`: 6 months of synthetic order-line activity (6,500 rows).
- `data/inventory_daily.csv`: October daily SKU-store inventory snapshots.
- `sql/analysis_queries.sql`: category, SKU, city/store and stock-risk SQL.
- `src/analyze.py`: reproducible Python analysis; creates KPI outputs and a suggested reorder list in `outputs/`.
- `dashboard_spec.md`: Power BI page layout, measures and visual guidance.
- `business_recommendations.md`: decision framework and hypotheses to validate.

## Run locally
```bash
pip install -r requirements.txt
python src/analyze.py
```
The script reads CSVs from `data/` and writes CSV summaries to `outputs/`.

## Core KPIs
- Net sales = quantity × unit selling price, excluding returned units.
- Gross profit = net sales − quantity × unit cost, excluding returned units.
- Gross margin % = gross profit / net sales.
- SKU availability proxy = share of store-day snapshots with closing stock > 0.
- Stock cover days = closing stock / trailing 7-day average daily sales (when available).
- Near-expiry share = near-expiry units / closing stock units.

## Analytical questions
1. Which subcategories drive sales and gross profit, not just order volume?
2. Which SKUs are high-velocity essentials and should have stronger safety stock?
3. Which SKUs have low sales, high stock cover or near-expiry exposure?
4. Does discount depth appear associated with unit movement and margin dilution?
5. Which city/store combinations show repeated stock-risk signals?

## Decision guardrails
- Treat formula, infant nutrition and health-related products as trust-sensitive. Do not recommend substitutions or claims about safety from sales data alone.
- Use age-stage and pack-size attributes only as merchandising dimensions, not medical advice.
- Reorder suggestions are planning estimates; validate supplier MOQs, case packs, actual lead times and store capacity before execution.
- Do not infer causal impact from correlations in this synthetic dataset.

## Suggested GitHub description
`A quick-commerce category management case study for baby-care: SKU profitability, availability, demand signals and store-level replenishment using SQL, Python and Power BI.`
