# Power BI Dashboard Specification

## Page 1 — Category Health
**Cards:** Net Sales, Gross Profit, Gross Margin %, Net Units, Orders, Avg Delivery Minutes  
**Charts:** Sales and profit by subcategory; monthly sales trend; category contribution; city x category matrix.  
**Slicers:** Date, city, category, brand, age stage.

## Page 2 — SKU & Pricing
**Charts:** Top 15 SKUs by sales; top 15 by gross profit; sales vs gross margin scatter; discount band vs units; low-margin/high-sales watchlist.  
**Table:** SKU, brand, subcategory, MRP, selling price, discount %, net units, net sales, gross margin %.

## Page 3 — Availability & Replenishment
**Cards:** Zero-stock store-SKU days, average stock cover, near-expiry units.  
**Charts:** Zero-stock days by subcategory; closing stock vs trailing demand; near-expiry units by store; suggested reorder quantity table.  
**Slicers:** Store, SKU, category.

## DAX measures (adjust table/column names to your model)
```DAX
Net Sales = SUMX(order_lines, order_lines[quantity] * order_lines[unit_selling_price_inr] * (1-order_lines[is_returned]))
Gross Profit = SUMX(order_lines, order_lines[quantity] * (order_lines[unit_selling_price_inr]-order_lines[unit_cost_inr]) * (1-order_lines[is_returned]))
Gross Margin % = DIVIDE([Gross Profit], [Net Sales])
Net Units = SUMX(order_lines, order_lines[quantity] * (1-order_lines[is_returned]))
Zero Stock Days = CALCULATE(COUNTROWS(inventory_daily), inventory_daily[closing_stock_units] = 0)
```
