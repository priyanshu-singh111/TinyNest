-- TinyNest Baby Essentials Category Intelligence & Smart Replenishment
-- Load CSVs into tables named sku_master, order_lines, inventory_daily.
-- SQL is ANSI-style; date syntax may need small changes by database.

-- 1. Category and subcategory performance
SELECT s.category, s.subcategory,
       SUM(o.quantity * o.unit_selling_price_inr * (1-o.is_returned)) AS net_sales_inr,
       SUM(o.quantity * (o.unit_selling_price_inr-o.unit_cost_inr) * (1-o.is_returned)) AS gross_profit_inr,
       SUM(o.quantity * (1-o.is_returned)) AS net_units,
       COUNT(DISTINCT o.order_id) AS orders
FROM order_lines o JOIN sku_master s ON o.sku_id=s.sku_id
GROUP BY s.category, s.subcategory
ORDER BY net_sales_inr DESC;

-- 2. SKU-level Pareto: rank by net sales and profit
SELECT s.sku_id, s.product_name, s.category,
       SUM(o.quantity * o.unit_selling_price_inr * (1-o.is_returned)) AS net_sales_inr,
       SUM(o.quantity * (o.unit_selling_price_inr-o.unit_cost_inr) * (1-o.is_returned)) AS gross_profit_inr,
       RANK() OVER (ORDER BY SUM(o.quantity * o.unit_selling_price_inr * (1-o.is_returned)) DESC) AS sales_rank
FROM order_lines o JOIN sku_master s ON o.sku_id=s.sku_id
GROUP BY s.sku_id, s.product_name, s.category;

-- 3. City-level category opportunity
SELECT o.city, s.category,
       SUM(o.quantity * o.unit_selling_price_inr * (1-o.is_returned)) AS net_sales_inr,
       AVG(o.delivery_minutes) AS avg_delivery_minutes,
       AVG(o.stockout_substitution * 1.0) AS substitution_rate
FROM order_lines o JOIN sku_master s ON o.sku_id=s.sku_id
GROUP BY o.city, s.category
ORDER BY o.city, net_sales_inr DESC;

-- 4. Daily store-SKU stock position and low-stock days
SELECT dark_store_id, sku_id,
       COUNT(*) AS snapshot_days,
       SUM(CASE WHEN closing_stock_units=0 THEN 1 ELSE 0 END) AS zero_stock_days,
       AVG(closing_stock_units) AS avg_closing_stock,
       SUM(near_expiry_units) AS near_expiry_units
FROM inventory_daily
GROUP BY dark_store_id, sku_id
ORDER BY zero_stock_days DESC, near_expiry_units DESC;

-- 5. Suggested replenishment: 7-day demand proxy + lead-time buffer.
-- Replace the illustrative 1.25 safety factor with a calibrated service-level policy.
WITH daily AS (
  SELECT dark_store_id, sku_id, snapshot_date, units_sold, closing_stock_units,
         AVG(units_sold * 1.0) OVER (
           PARTITION BY dark_store_id, sku_id
           ORDER BY snapshot_date ROWS BETWEEN 6 PRECEDING AND CURRENT ROW
         ) AS avg_daily_units_7d
  FROM inventory_daily
),
latest AS (
  SELECT d.*,
         ROW_NUMBER() OVER (PARTITION BY dark_store_id, sku_id ORDER BY snapshot_date DESC) AS rn
  FROM daily d
)
SELECT l.dark_store_id, l.sku_id, l.closing_stock_units,
       ROUND(l.avg_daily_units_7d,2) AS avg_daily_units_7d,
       s.supplier_lead_time_days,
       CEILING(l.avg_daily_units_7d * s.supplier_lead_time_days * 1.25) AS target_stock,
       GREATEST(0, CEILING(l.avg_daily_units_7d * s.supplier_lead_time_days * 1.25)-l.closing_stock_units) AS suggested_reorder_units
FROM latest l JOIN sku_master s ON l.sku_id=s.sku_id
WHERE l.rn=1
ORDER BY suggested_reorder_units DESC;
